<?php
class MailControllerWpf extends ControllerWpf {
	
}
