<?php
class PagesControllerWpf extends ControllerWpf {

}
